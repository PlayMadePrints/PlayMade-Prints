
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";

export default function PlayMadePrints() {
  const [quantity, setQuantity] = useState(1);
  const [isPickup, setIsPickup] = useState(false);
  const [productType, setProductType] = useState("Lightbox");

  const priceMap = {
    Lightbox: 40,
    Ashtray: 12,
    "Rolling Tray": 14
  };

  const pricePerItem = priceMap[productType];
  const taxRate = 0.05; // 5% Wisconsin tax
  const shipping = isPickup
    ? 0
    : productType === "Ashtray" || productType === "Rolling Tray"
    ? 7
    : 9;
  const subtotal = quantity * pricePerItem;
  const tax = subtotal * taxRate;
  const totalPrice = subtotal + tax + shipping;

  return (
    <main className="bg-black text-teal-400 min-h-screen font-sans">
      <motion.header 
        className="relative w-full h-screen flex items-center justify-center text-center"
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ duration: 1.5 }}
      >
        <img 
          src="/images/file_0000000047386230b69726c454c4b755.png" 
          alt="PlayMade Prints Logo" 
          className="absolute object-cover w-full h-full z-0"
        />
        <div className="absolute inset-0 bg-black opacity-60 z-10" />
        <div className="z-20 text-white px-4">
          <motion.h1 
            className="text-5xl md:text-6xl font-bold mb-4"
            initial={{ scale: 0.8 }} 
            animate={{ scale: 1 }} 
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            PlayMade Prints
          </motion.h1>
          <motion.p 
            className="text-xl md:text-2xl text-teal-300"
            initial={{ y: 20, opacity: 0 }} 
            animate={{ y: 0, opacity: 1 }} 
            transition={{ duration: 1.0 }}
          >
            Custom 3D Creations for Every Style
          </motion.p>
        </div>
      </motion.header>
      ...
    </main>
  );
}
